This is a python based phonebook app.
The app is compatible with Python3 language.
The phonebook allows storing people's phone number and email, with some verifications built-in.
Here are the features of the phonebook:
1. Add a new contact
2. Delete a contact
3. Update contact list
4. Delete all contacts
5. Search a contact
6. Print the contact list

Features pending:
1. Add, Update, and Delete several contacts at once
2. Integration of Search to Update command

Please feel free to contribute and suggest for any features that I should add. 
